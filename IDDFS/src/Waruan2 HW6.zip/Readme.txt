Main Function is in AStar.java

heuristics is set to Manhanntan Distance on default
Change int heuristics = 1; on line 22 to 0 for dispalcement



Input format example:

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 0
1 2 3 4 5 6 7 8 9 10 11 12 13 14 0 15
1 6 2 4 9 0 5 8 10 7 3 11 13 14 15 12
0 5 3 4 2 1 7 8 10 6 15 11 9 13 14 12

Program does not check for duplicated input 

Program print the memory and time use for each deeping search

0 is used to indicate that it a blank tile.

Used the DefaultMutableTreeNode to create tree.

Used http://www.java2s.com/Code/Java/Swing-JFC/Asimpletesttoseehowwecanbuildatreeandpopulateit.htm
as a reference for creating tree
