Readme



Sample Input


11 Alt 2 T F Bar 2 T F Fri 2 T F Hun 2 T F Pat 3 Some Full None Price 3 $ $$ $$$ Rain 2 T F Res 2 T F Type 4 French Thai Burger Italian Est 4 0–10 10–30 30–60 >60 WillWait 2 T F
12
T F F T Some $$$ F T French 0–10 T
T F F T Full $ F F Thai 30–60 F
F T F F Some $ F F Burger 0–10 T
T F T T Full $ F F Thai 10–30 T
T F T F Full $$$ F T French >60 F
F T F T Some $$ T T Italian 0–10 T
F T F F None $ T F Burger 0–10 F
F F F T Some $$ T T Thai 0–10 T
F T T F Full $ T F Burger >60 F
T T T T Full $$$ F T Italian 10–30 F
F F F F None $ F F Thai 0–10 F
T T T T Full $ F F Burger 30–60 T
