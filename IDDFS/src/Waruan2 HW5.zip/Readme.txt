Main Function is in IDDFS

Input format example:

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 0
1 2 3 4 5 6 7 8 9 10 11 12 13 14 0 15


Program does not check for duplicated input 

Program print the memory and time use for each deeping search

0 is used to indicate that it a blank tile.

Used the DefaultMutableTreeNode to create tree.

Used http://www.java2s.com/Code/Java/Swing-JFC/Asimpletesttoseehowwecanbuildatreeandpopulateit.htm
as a reference for creating tree
